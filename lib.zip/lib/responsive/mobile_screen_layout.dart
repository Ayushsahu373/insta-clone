import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:insta_clone/Screens/add_post_screen.dart';
import 'package:insta_clone/utils/colors.dart';

class MobileScreenLayout extends StatefulWidget {
  const MobileScreenLayout({super.key});

  @override
  _MobileScreenLayoutState createState() => _MobileScreenLayoutState();
}

class _MobileScreenLayoutState extends State<MobileScreenLayout> {
  int _page = 0; // Track selected index
  late PageController pageController;

  @override
  void initState() {
    super.initState();
    pageController = PageController();
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  void navigationTapped(int page) {
    pageController.jumpToPage(page);
  }

  void onPageChange(int page) {
    setState(() {
      _page = page;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: [
          Center(child: Text("feed", style: TextStyle(color: primaryColor))),
          Center(child: Text("search", style: TextStyle(color: primaryColor))),
          AddPostScreen(),
          Center(child: Text("notifications", style: TextStyle(color: primaryColor))),
          Center(child: Text("profile", style: TextStyle(color: primaryColor))),
        ],
        physics: const NeverScrollableScrollPhysics(),
        controller: pageController,
        onPageChanged: onPageChange,
      ),
      bottomNavigationBar: CurvedNavigationBar(
        height: 50,
        items: <Widget>[
          Icon(Icons.home, size: 30, color: _page == 0 ? instagramPinkColor : Colors.grey),
          Icon(Icons.search, size: 30, color: _page == 1 ? instagramPinkColor : Colors.grey),
          Icon(Icons.add_circle_outline, size: 30, color: _page == 2 ? instagramPinkColor : Colors.grey),
          Icon(Icons.favorite_outlined, size: 30, color: _page == 3 ? instagramPinkColor : Colors.grey),
          Icon(Icons.person, size: 30, color: _page == 4 ? instagramPinkColor : Colors.grey),
        ],
        color: Colors.white,
        buttonBackgroundColor: Colors.white,
        backgroundColor: instagramOrangeColor,
        animationCurve: Curves.linear,
        animationDuration: const Duration(milliseconds: 300),
        onTap: (index) {
          setState(() {
            _page = index;
            navigationTapped(_page);
          });
        },
      ),
    );
  }
}
