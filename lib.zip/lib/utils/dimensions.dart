
const webScreenSize = 600;
