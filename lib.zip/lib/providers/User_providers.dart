import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:insta_clone/models/user.dart';
import 'package:insta_clone/resources/auth_methods.dart';

// StateNotifier to manage User state with Riverpod
class UserNotifier extends StateNotifier<User?> {
  UserNotifier() : super(null);

  User? get user => state;

  Future<void> refreshUser() async {
    User user = await AuthMethods().getUserDetails();
    state = user; // Update state directly
  }
}

// Riverpod provider for accessing UserNotifier
final userProvider = StateNotifierProvider<UserNotifier, User?>(
  (ref) => UserNotifier(),
);
