import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:insta_clone/resources/auth_methods.dart';
import 'package:insta_clone/resources/storage_methods.dart';
import 'package:insta_clone/utils/colors.dart';
import 'package:insta_clone/utils/utils.dart';
import 'package:uuid/uuid.dart';

class AddPostScreen extends ConsumerStatefulWidget {
  const AddPostScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<AddPostScreen> createState() => _AddPostScreenState();
}

class _AddPostScreenState extends ConsumerState<AddPostScreen> {
  Uint8List? _file;
  final TextEditingController _descriptionController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  void postImage() async {
    if (_file == null) {
      showSnackbar( 'Please select an image',context);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final user = await ref.read(authMethodsProvider).getUserDetails();
      final uid = user.uid;

      String photoUrl = await ref.read(storageMethodsProvider).uploadImageToStorage(
            'posts',
            _file!,
            true,
          );

      final postId = const Uuid().v1(); // Unique post ID
      await FirebaseFirestore.instance.collection('posts').doc(postId).set({
        'postId': postId,
        'uid': uid,
        'description': _descriptionController.text,
        'photoUrl': photoUrl,
        'username': user.username,
        'datePublished': DateTime.now(),
        'likes': [],
      });

      showSnackbar( 'Posted successfully!',context,);
      clearImage();
    } catch (e) {
      showSnackbar( e.toString(),context);
    }

    setState(() {
      _isLoading = false;
    });
  }

  void clearImage() {
    setState(() {
      _file = null;
    });
    _descriptionController.clear();
  }

  Future<void> selectImage() async {
    Uint8List file = await pickImage(ImageSource.gallery);
    setState(() {
      _file = file;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: mobileBackgroundColor,
        title: const Text('Add Post'),
        centerTitle: false,
        actions: [
          TextButton(
            onPressed: postImage,
            child: const Text(
              "Post",
              style: TextStyle(
                color: Colors.blueAccent,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_isLoading) const LinearProgressIndicator(),
          const Divider(),
          _file == null
              ? Center(
                  child: IconButton(
                    icon: const Icon(Icons.upload, size: 50),
                    onPressed: selectImage,
                  ),
                )
              : Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: NetworkImage(ref
                              .read(authMethodsProvider)
                              .getUserDetails()
                              .then((user) => user.photoUrl)
                              .toString()),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.3,
                          child: TextField(
                            controller: _descriptionController,
                            decoration: const InputDecoration(
                              hintText: "Write a caption...",
                              border: InputBorder.none,
                            ),
                            maxLines: 2,
                          ),
                        ),
                        SizedBox(
                          height: 45,
                          width: 45,
                          child: AspectRatio(
                            aspectRatio: 487 / 451,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: MemoryImage(_file!),
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(),
                  ],
                ),
        ],
      ),
    );
  }
}
