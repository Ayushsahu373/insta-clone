import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:insta_clone/Screens/login_screen.dart';
import 'package:insta_clone/Widgets/text_input_field.dart';
import 'package:insta_clone/responsive/mobile_screen_layout.dart';
import 'package:insta_clone/responsive/responsive_layout_screen.dart';
import 'package:insta_clone/responsive/web_screen_layout.dart';
import 'package:insta_clone/utils/colors.dart';
import 'package:insta_clone/resources/auth_methods.dart';
import 'package:insta_clone/utils/utils.dart';
import 'package:snackbar/snackbar.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreen();
}

class _SignupScreen extends State<SignupScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _userNameController = TextEditingController();
  Uint8List? _image;
  bool _isloading = false;
  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _userNameController.dispose();
    _bioController.dispose();
  }

  void SelectImage() async {
    Uint8List? img = await pickImage(ImageSource.gallery);
    setState(() {
      _image = img;
    });
  }

  signup() async {
    {
      // Check if any field is empty
      if (_emailController.text.isEmpty ||
          _passwordController.text.isEmpty ||
          _userNameController.text.isEmpty ||
          _bioController.text.isEmpty ||
          _image == null) {
        showSnackbar("Please fill all fields and select an image", context);
        return;
      }
    }
    if (isValidEmail(_emailController.text) == false) {
      showSnackbar("enter valid email", context);
      return;
    }
    // Set loading to true
    setState(() {
      _isloading = true;
    });

    // Call the signup method
    String res = await AuthMethods().signUpUser(
      email: _emailController.text,
      password: _passwordController.text,
      username: _userNameController.text,
      bio: _bioController.text,
      file: _image!,
    );

    // Check the response
    if (res == "Successfully signed up!") {
      showSnackbar(res, context);
      Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context)=> const ResponsiveLayout(
                webScreenLayout: WebScreenLayout(),
                mobileScreenLayout: MobileScreenLayout()),
          ),
        );  } else {
      showSnackbar(res, context);
    }

    // Set loading to false
    setState(() {
      _isloading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 32),
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Flexible(
                child: Container(),
                flex: 1,
              ),
              //svg image
              SvgPicture.asset(
                'assets/ic_instagram.svg',
                color: primaryColor,
                height: 54,
              ),
              //circular avt
              Stack(
                children: [
                  _image != null
                      ? CircleAvatar(
                          radius: 44, backgroundImage: MemoryImage(_image!))
                      : const CircleAvatar(
                          radius: 44,
                          backgroundImage: AssetImage("assets/userAvt.png")),
                  Positioned(
                    bottom: -10,
                    right: -5,
                    child: IconButton(
                      onPressed: () {
                        SelectImage();
                      },
                      icon: Icon(
                        Icons.add_a_photo,
                        size: 30,
                        color: Colors.grey,
                      ),
                    ),
                  )
                ],
              ),
              //  /texrfield ip for email
              const SizedBox(
                height: 44,
              ),
              TextInputField(
                textEditingController: _userNameController,
                isPass: false,
                hintText: 'Enter your Username',
                textInputType: TextInputType.emailAddress,
              ),
              const SizedBox(
                height: 20,
              ),
              TextInputField(
                textEditingController: _emailController,
                isPass: false,
                hintText: 'Enter your email',
                textInputType: TextInputType.emailAddress,
              ),
              const SizedBox(
                height: 20,
              ),
              //tf for password
              TextInputField(
                  textEditingController: _passwordController,
                  isPass: true,
                  hintText: 'Enter your password',
                  textInputType: TextInputType.text)
              //login button
              ,
              const SizedBox(
                height: 20,
              ),
              TextInputField(
                textEditingController: _bioController,
                isPass: false,
                hintText: 'Enter your bio',
                textInputType: TextInputType.text,
              ),
              const SizedBox(
                height: 20,
              ),
              InkWell(
                onTap: () async {
                  if (_image == null && isValidEmail(_emailController.text)) {
                    showSnackbar('Please select a profile image.', context);
                    return;
                  }
                  signup();
                },
                child: Container(
                  width: double.infinity,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: const ShapeDecoration(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                    ),
                    color: blueColor,
                  ),
                  child: _isloading
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: primaryColor,
                          ),
                        )
                      : const Text("Sign up",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                ),
              ),
              Flexible(
                child: Container(),
                flex: 11,
              ),
              //transitioning to signup
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Text(" have an account?",
                        style: TextStyle(
                          color: Colors.white,
                        )),
                    padding: const EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()));
                    },
                    child: Container(
                      child: Text(
                        " Log in.",
                        style: TextStyle(
                          color: blueColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
